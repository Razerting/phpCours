<?php

class Voiture{

	private $wheel = 4;
	private $volant = true;
	protected $vitres = 6;

	public function __construct(){
		echo "construction de la voiture<br>";
	}

	public function getVitres(){
		return $this->vitres;
	}

}

class Twingo extends Voiture{
	//public $color = "gris";
	private $color;
	private static $carTech = ["moteur"=>"V8", "poids"=>"800kg"];
	//protected $color = "gris";

	public function __construct($color = "gris"){

		parent::__construct();

		if(!empty($color)){
			$this->setColor($color);
		}
	}

	public function getColor(){
		return $this->color;
	}
	public function setColor($color){
		$this->color = strtolower(trim($color));
	}

	public static function getCarTech(){
		return self::$carTech;
	}

	public function __destruct(){
		echo "<br>La voiture est prête<br>";
	}

	public function getVitres(){
		return $this->vitres/2;
	}

}
//$twingo1 est un objet
//$twingo1 est une instance de la class twingo
//print_r(Twingo::getCarTech());
$twingo1 = new Twingo("bleu");
echo $twingo1->getVitres();


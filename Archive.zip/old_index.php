<?php
	include "header.php";
?>

<section>
	<?php
		/* 
			commentaire sur plusieurs lignes
		
		//sur une seule ligne
		

		$userName = "skrzypczyk";

		echo "Bonjour ".$userName."<br>";

		$number1 = 3;
		$number2 = 5;
		echo "Le résultat de ".$number1."+".$number2." donne ".($number1+$number2)."<br>";

		$cpt = 0;
		echo $cpt; //0
		$cpt = $cpt+1;
		echo $cpt; //1
		$cpt += 1;
		echo $cpt; //2
		$cpt++;
		echo $cpt; //3
		++$cpt;
		echo $cpt; //4
		echo $cpt++; //4
		echo $cpt; //5
		echo ++$cpt; //6
		

		$number1 = 4;

		if($number1 % 2 == 0) echo "paire";
		else echo "impaire";
		
		*/

		$number1 = 4;
		$number2 = 0;
		$signe = "-";

		/*
		if($signe == "+"){
			$result = $number1+$number2;
		}else if($signe == "*"){
			$result = $number1*$number2;
		}else if($signe == "/" && $number2 != 0){
			$result = $number1/$number2;
		}else if($signe == "-"){
			$result = $number1-$number2;
		}else{
			$result="ERROR";
		}

		//   (condition)?vrai:false;

		switch ($signe) {
			case '+':
				$result = $number1+$number2;
				break;
			case '-':
				$result = $number1-$number2;
				break;
			case '*':
				$result = $number1*$number2;
				break;
			case '/':
				$result = ($number2==0)?"ERROR":$number1/$number2;
				break;
			default:
				$result="ERROR";
				break;
		}

		echo "Le résultat de ".$number1." ".$signe." ".$number2." donne ".$result;
		


		$eleve = ["lastname"=>"Louis", "firstname"=>"Jeremy", "age"=>21];


		echo $eleve["firstname"];
		$eleve["average"] = 10 ;
		echo "<pre>";
		print_r($eleve);
		echo "</pre>";
		

		$class = [
					0=>["lastname"=>"Bertin", "firstname"=>"Louis"],
					1=>["lastname"=>"Vie", "firstname"=>"Yoann"],
					2=>["lastname"=>"Mayon", "firstname"=>"Maël"],
				];

	?>

	<table>
		<thead>
			<tr>
				<th>Id</th>
				<th>Nom</th>
				<th>Prénom</th>
			</tr>
		</thead>
		<tbody>
			<?php

				foreach ($class as $key => $value) {
					echo "<tr>";
					echo "<td>".$key."</td>";
					echo "<td>".$value["lastname"]."</td>";
					echo "<td>".$value["firstname"]."</td>";
					echo "</tr>";
				}

			?>
		</tbody>
	</table>


	<?php
		for( $i=0 ; $i<100 ; $i++){
			echo $i;
		}

		$j = 0;
		while($j<100){

			$j++;
		}


		$j = 100;
		do{

		}while ($j<100);
	


	//afficher les X premiers nombres premiers
	$x = 100;
	$cpt = 0;
	$numberTested = 2;

	while ($x>0) {
		$isFirst = true;

		for($i=2 ; $i<=sqrt($numberTested) ; $i++){
			if($numberTested%$i == 0){
				$isFirst = false;
				break;
			}
		}
		if($isFirst){
			echo ++$cpt." -> ". $numberTested."<br>";
			$x--;
		}
		$numberTested++;
	}
	



	function helloWord(){
		echo "Bonjour tout le monde<br>";
	}

	helloWord();



	function helloYou($firstname, $lastname="Dupont"){
		echo "Bonjour ".cleanWorld($firstname).
		" ".cleanWorld($lastname, true)."<br>";
	}


	helloYou("éyvées", "skrzyépczyk");
	helloYou("yves");

	//Soit mettre la premiere lettre, soit tout le mot en majuscule
	//Attention un caractère special ne peut pas être en majuscule
	function cleanWorld($world, $allUpper = false){
		$world = trim($world);

		if($allUpper){
			replaceAccents($world);
			$world = strtoupper($world);
		}else{
			$firstChar = mb_substr($world, 0, 1, 'utf-8');
			replaceAccents($firstChar);
			$world = $firstChar.mb_substr($world, 1, strlen($world), 'utf-8');
			$world = strtolower($world);
			$world = ucfirst($world);	
		}

		return $world;
	}

	function replaceAccents(&$world){ 
   	 	$world = str_replace( 
   	 			['à','á','â','ã','ä', 'ç', 'è','é','ê','ë', 'ì','í','î','ï', 'ñ', 'ò','ó','ô','õ','ö', 'ù','ú','û','ü', 'ý','ÿ', 'À','Á','Â','Ã','Ä', 'Ç', 'È','É','Ê','Ë', 'Ì','Í','Î','Ï', 'Ñ', 'Ò','Ó','Ô','Õ','Ö', 'Ù','Ú','Û','Ü', 'Ý'], 

   	 			['a','a','a','a','a', 'c', 'e','e','e','e', 'i','i','i','i', 'n', 'o','o','o','o','o', 'u','u','u','u', 'y','y', 'A','A','A','A','A', 'C', 'E','E','E','E', 'I','I','I','I', 'N', 'O','O','O','O','O', 'U','U','U','U', 'Y'], 

   	 			$world);
	}



	$age = 12;

	function showAge(){
		global $age;
		echo $age;
	}

	showAge();
	
	*/

	?>

</section>

<?php
	include "footer.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Titre de ma page</title>
		<meta name="description" content="description de ma page">
	</head>
	<body>
		<header>

			<nav></nav>
		</header>
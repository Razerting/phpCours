<?php

	header("Content-type: image/png");

	$image = imagecreate(200,50); 	

	$black = imagecolorallocate($image, 0, 0, 0); 
	$white = imagecolorallocate($image, 255,255,255); 

	imagestring($image, 5, 100, 25, "Bonjour", $white);

	ImageLine ($image, 0, 0, 200,50, $white); 

//Captcha unique avec des chiffres et des lettres
	//une taille dynamique (max et min)
	//Couleur de fond dynamique
	//Couleur des caractères dynamiques
	//Police (doit se trouver dans un dossier font et c'est le php  qui liste toutes les polices dispo) et taille des caractères dynamiques
	//nombre de Formes géométriques (carré, rond, ...) aléatoire sur l'image
	//Angle des caractères aléatoires
	//Attention a la lisibilité
	//OPTION : Lecture des caractères (mp3) par le navigateur
	imagepng($image);